package net.sf.pizzacompiler.compiler;

/**
 * $Id: WarningMessage.java,v 1.3 2001/09/14 15:26:08 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 11:46:58 2001
 */

public class WarningMessage extends ErrorMessage {
  public WarningMessage(String source, Position pos, String message){
    super(source, pos, message);
  }

  public boolean isError() {
    return false;
  }

  public String toString() {
    StringBuffer result = new StringBuffer();
    appendLocationString(result);
    result.append("warning: ");
    result.append(getMessage());
    return result.toString();
  }
  
}// WarningMessage
