package net.sf.pizzacompiler.compiler;

/**
 * $Id: SourceReader.java,v 1.1 2001/09/03 16:04:33 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 15:50:26 2001
 */

import java.io.File;
import java.io.InputStream;
import java.io.IOException;

public abstract class SourceReader {
  protected SourceReader (){
  }

  public abstract InputStream getInputStream(String source) throws IOException;

  public byte[] readAll(String source) throws IOException {
    InputStream in = null;
    try {
      in = getInputStream(source);
      byte [] buf = new byte[in.available()];
      in.read(buf);
      return buf;
    } finally {
      if(in != null) {
	in.close();
      }
    }
  }

  /**
   * we need to be able to say if we have read an input file, so we
   * don't overwrite input files
   */
  public boolean haveRead(File source) {
    return false;
  }
}// SourceReader
