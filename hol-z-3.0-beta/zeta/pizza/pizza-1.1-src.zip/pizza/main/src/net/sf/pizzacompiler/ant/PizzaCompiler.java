package net.sf.pizzacompiler.ant;

/**
 * $Id: PizzaCompiler.java,v 1.1.1.1 2001/08/29 15:35:39 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue
 * This software is distributed under the Artistic License. See 
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Tue Aug 28 16:47:20 2001
 */

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.Execute;
import org.apache.tools.ant.taskdefs.Javac;
import org.apache.tools.ant.taskdefs.LogStreamHandler;
import org.apache.tools.ant.taskdefs.compilers.DefaultCompilerAdapter;
import org.apache.tools.ant.types.Commandline;
import org.apache.tools.ant.types.Path;

import java.io.IOException;
/**
 * An adapter for letting you use Pizza in an ant build process.
 */
public class PizzaCompiler extends DefaultCompilerAdapter {
  public PizzaCompiler (){
    
  }

  /**
   * Executes the task.
   *
   * @return has the compilation been successful
   */
  public boolean execute() throws BuildException {
    Commandline cmd = new Commandline();
    cmd.setExecutable("java");
    addPizzaCompilerClasses(cmd);
    cmd.createArgument().setValue("net.sf.pizzacompiler.compiler.Main");

    addDestinationDir(cmd);
    addClasspath(cmd);

    int firstFileName = cmd.size();
    logAndAddFilesToCompile(cmd);

    return executeExternalCompile(cmd.getCommandline(), firstFileName) == 0;
  }


  /**
   * Pizza doesn't understand the @syntax for giving a list of files
   * to compiler in a files rather than on command line, so we need to
   * override this
   */
  protected int executeExternalCompile(String[] args, int firstFileName) {
    try {
      Execute exe = new Execute(new LogStreamHandler(attributes, 
						     Project.MSG_INFO,
						     Project.MSG_WARN));
      exe.setAntRun(project);
      exe.setWorkingDirectory(project.getBaseDir());
      exe.setCommandline(args);
      exe.execute();
      return exe.getExitValue();
    } catch (IOException e) {
      throw new BuildException("Error running " + args[0] 
			       + " compiler", e, location);
    }
  }


  private void addDestinationDir(Commandline cmd) {
    if (destDir != null) {
      cmd.createArgument().setValue("-d");
      cmd.createArgument().setFile(destDir);
    }
  }

  private void addClasspath(Commandline cmd) {
    cmd.createArgument().setValue("-classpath");
    cmd.createArgument().setPath(compileClasspath);
  }

  private void addPizzaCompilerClasses(Commandline cmd) {
    String pizzaClassesProperty = 
      project.getProperty("build.compiler.pizza.classes");
    if(pizzaClassesProperty != null) {
      cmd.createArgument().setValue("-classpath");
      cmd.createArgument().setPath(new Path(project, pizzaClassesProperty));
    }
  }

}// PizzaCompiler
