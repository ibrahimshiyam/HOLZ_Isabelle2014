package net.sf.pizzacompiler.compiler;

/**
 * $Id: ByteArrayCompilerOutput.java,v 1.1 2001/09/19 10:55:54 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Wed Sep 19 11:37:45 2001
 */

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;

/**
 * Take the classes and source code output by the compiler to byte
 * arrays. Useful for embedding the pizza compiler.
 */
public class ByteArrayCompilerOutput implements CompilerOutput {
  private Map _streams;
  
  public ByteArrayCompilerOutput() {
    _streams = new HashMap();
  }
  
  public OutputStream getClassOutputStream(String sourceFile, 
					   String classFullName) 
    throws IOException {
    return makeOutputStream(classFullName);
  }
  
  public OutputStream getSourceOutputStream(String sourceFile, 
					    String classFullName, 
					    SourceReader reader,
					    int pos) 
    throws IOException {
    return makeOutputStream(classFullName);
  }
  
  private OutputStream makeOutputStream(final String streamName) 
    throws IOException {
    ByteArrayOutputStream stream = new ByteArrayOutputStream();
    _streams.put(streamName, stream);
    return stream;
  }
  
  public Collection getBytecode() {
    ArrayList code = new ArrayList();
    for(Iterator i = _streams.values().iterator(); i.hasNext();) {
      ByteArrayOutputStream baos = (ByteArrayOutputStream)i.next();
      code.add(baos.toByteArray());
    }
    return code;
  }
}// ByteArrayCompilerOutput
