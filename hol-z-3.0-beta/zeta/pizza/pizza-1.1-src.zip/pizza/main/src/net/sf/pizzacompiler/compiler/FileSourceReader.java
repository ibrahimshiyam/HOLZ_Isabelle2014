package net.sf.pizzacompiler.compiler;

/**
 * $Id: FileSourceReader.java,v 1.3 2001/09/03 16:04:33 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 13:58:50 2001
 */

import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashSet;

/**
 * Implements something to which all accesses to java/pizza source can
 * go through. Uses file system.
 */

public class FileSourceReader extends SourceReader {
  private HashSet _readFiles;

  public FileSourceReader() {
    _readFiles = new HashSet();
  }
  
  public InputStream getInputStream(String source) throws IOException {
    _readFiles.add(new File(source));
    return new FileInputStream(source);
  }

  public boolean haveRead(File source) {
    return _readFiles.contains(source);
  }
}// FileSourceReader
