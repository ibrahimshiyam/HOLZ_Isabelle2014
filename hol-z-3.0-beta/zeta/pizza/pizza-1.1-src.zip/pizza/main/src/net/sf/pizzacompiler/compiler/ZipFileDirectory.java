package net.sf.pizzacompiler.compiler;

/**
 * $Id: ZipFileDirectory.java,v 1.1 2001/10/01 13:56:38 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Oct 01 13:40:53 2001
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipFileDirectory {
  private HashMap _directories;
  private ZipFile _file;

  public ZipFileDirectory(ZipFile file){
    _file = file;
  }
  
  private void fillDirectories(ZipFile file) {
    _directories = new HashMap();
    for (java.util.Enumeration e = file.entries(); e.hasMoreElements(); ) {
      ZipEntry entry = (ZipEntry)e.nextElement();
      String ename = entry.getName();
      int slashIndex = ename.lastIndexOf('/');
      String dir = slashIndex == -1 ? "" : ename.substring(0, slashIndex);
      String name = slashIndex == -1 ? ename : ename.substring(slashIndex+1);
      if(name.length() > 0) {
	addEntry(dir, name);
      }
    }
  }

  private void addEntry(String dir, String name) {
    ArrayList entries = (ArrayList)_directories.get(dir);
    if(entries == null) {
      entries = new ArrayList();
      _directories.put(dir, entries);
    }
    entries.add(name);
  }

  public String [] listFiles(String directory) {
    if(_directories == null) {
      fillDirectories(_file);
    }
    if (directory.length() != 0) {
      directory = directory.replace('\\', '/');
      if (directory.endsWith("/")) directory = directory.substring(0, directory.length()-1);
    }
    ArrayList entries = (ArrayList)_directories.get(directory);
    return entries == null ? new String[0] :
      (String[])entries.toArray(new String[0]);
  }
}// ZipFileDirectory
