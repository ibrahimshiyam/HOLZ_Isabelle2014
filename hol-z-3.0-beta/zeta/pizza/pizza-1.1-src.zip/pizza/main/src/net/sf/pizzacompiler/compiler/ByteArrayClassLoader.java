package net.sf.pizzacompiler.compiler;

/**
 * $Id: ByteArrayClassLoader.java,v 1.1 2001/09/19 10:55:54 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Wed Sep 19 11:39:25 2001
 */

import java.util.*;

/**
 * A ClassLoader for loading classes from a <code>Collection</code> of
 * <code>byte[]</code> such as that provided by
 * <code>ByteArrayCompilerOutput</code>. Useful for using pizza in an
 * embedded context.
 */
public class ByteArrayClassLoader extends ClassLoader {
  private Map _namesToClasses;
  
  public ByteArrayClassLoader(ClassLoader parentClassLoader,
			      Collection bytecode) {
    super(parentClassLoader);
    _namesToClasses = new HashMap();
    for(Iterator i = bytecode.iterator(); i.hasNext();) {
      byte [] code = (byte [])i.next();
      Class aClass = super.defineClass(null, code, 0, code.length);
      _namesToClasses.put(aClass.getName(), aClass);
    }
  }
  
  public Class findClass( String name ) throws ClassNotFoundException {
    Class theClass = (Class)_namesToClasses.get(name);
    if(theClass == null) {
      throw new ClassNotFoundException(name);
    } else {
      return theClass;
    }
  }
}// ByteArrayClassLoader
