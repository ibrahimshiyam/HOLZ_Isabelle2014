package net.sf.pizzacompiler.compiler;

/**
 * $Id: CompilerOutput.java,v 1.1 2001/09/14 11:08:04 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Fri Sep 14 10:31:53 2001
 */

import java.io.IOException;
import java.io.OutputStream;

/**
 * Something that can write pizza's output, either java source, or
 * java VM classes
 */
public interface CompilerOutput {
  /**
   * get an OutputStream for writing a java VM class. 
   * @param sourceFile the original file name that was used to
   *                   generate this class
   * @param classFullName the full name of the class being generated
   */
  public OutputStream getClassOutputStream(String sourceFile, 
					   String classFullName) 
    throws IOException;
  /**
   * get an OutputStream for writing a java VM class. 
   * @param sourceFile the original file name that was used to
   *                   generate this source code
   * @param classFullName the full name of the class being generated
   */
  public OutputStream getSourceOutputStream(String sourceFile, 
					    String classFullName, 
					    SourceReader reader,
					    int pos) 
    throws IOException;
}// CompilerOutput
