package net.sf.pizzacompiler.ant;

/**
 * $Id: Pizzac.java,v 1.1.1.1 2001/08/29 15:35:39 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue
 * This software is distributed under the Artistic License. See 
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Wed Aug 29 10:14:56 2001
 */

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.taskdefs.Javac;
import org.apache.tools.ant.util.GlobPatternMapper;
import org.apache.tools.ant.util.SourceFileScanner;
import java.io.File;

public class Pizzac extends Javac {
  private static final String COMPILER_PROPERTY = "build.compiler";

  public Pizzac (){
    
  }

  /**
   * for now we know to use the pizza compiler
   */
  public void execute() throws BuildException {
    String oldCompiler = project.getProperty(COMPILER_PROPERTY);
    project.setProperty(COMPILER_PROPERTY,
			"net.sf.pizzacompiler.ant.PizzaCompiler");
    super.execute();
    resolveCompiler(oldCompiler);
  }
   
  protected void resolveCompiler(String oldCompiler) {
    if (oldCompiler == null) {
      if (project.getJavaVersion().startsWith("1.3")) {
	setCompiler("modern");
      } else {
	setCompiler("classic");
      }
    } else {
      setCompiler(oldCompiler);
    }
  }

  private void setCompiler(String compiler) {
    project.setProperty(COMPILER_PROPERTY, compiler);
  }

  /**
   * look for pizza files, then use javac task to look for .java files
   */
  protected void scanDir(File srcDir, File destDir, String files[]) {
    super.scanDir(srcDir, destDir, files);
    GlobPatternMapper m = new GlobPatternMapper();
    m.setFrom("*.pizza");
    m.setTo("*.class");
    SourceFileScanner sfs = new SourceFileScanner(this);
    File[] newFiles = sfs.restrictAsFiles(files, srcDir, destDir, m);
        
    if (newFiles.length > 0) {
      File[] newCompileList = new File[compileList.length +
				      newFiles.length];
      System.arraycopy(compileList, 0, newCompileList, 0,
		       compileList.length);
      System.arraycopy(newFiles, 0, newCompileList,
		       compileList.length, newFiles.length);
      compileList = newCompileList;
    }
  }
  
}// Pizzac
