package net.sf.pizzacompiler.compiler;

/**
 * $Id: ErrorMessage.java,v 1.3 2001/09/14 15:26:08 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 11:46:05 2001
 */

public class ErrorMessage {
  private String _source;
  private Position _pos;
  private String _message;

  public ErrorMessage(String source, Position pos, String message){
    _source = source;
    _pos = pos;
    _message = message;
  }
  
  public String getSource() {
    return _source;
  }

  public Position getPosition() {
    return _pos;
  }

  public String getMessage() {
    return _message;
  }

  public boolean isError() {
    return true;
  }

  protected void appendLocationString(StringBuffer result) {
    if(getPosition().isValid()) {
      result.append(getSource());
      result.append(':');
      result.append(getPosition().getLine());
    } else {
      result.append("error");
    }
    result.append(':');
    result.append(' ');
  }

  public boolean equals(Object o) {
    if(o == this) {
      return true;
    }
    if(!(o instanceof ErrorMessage)) {
      return false;
    }
    ErrorMessage other = (ErrorMessage)o;
    return getPosition().equals(other.getPosition()) &&
      getSource().equals(other.getSource());
  }

  public int hashCode() {
    return getPosition().hashCode() ^ 
      getSource().hashCode();
  }

  public String toString() {
    StringBuffer result = new StringBuffer();
    appendLocationString(result);
    result.append(getMessage());
    return result.toString();
  }
}// ErrorMessage
