package net.sf.pizzacompiler.compiler;

/**
 * $Id: MapSourceReader.java,v 1.1 2001/09/03 16:04:33 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 15:28:18 2001
 */

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.*;

public class MapSourceReader extends SourceReader {
  private Map _sourceNameToJavaSource;

  public MapSourceReader(Map sourceNameToJavaSource) 
    throws MapSourceReaderException {
    try {
      sourceNameToJavaSource.keySet().toArray(new String[0]);
      sourceNameToJavaSource.values().toArray(new String[0]);
    } catch(ArrayStoreException e) {
      throw new MapSourceReaderException("Map must be String to String");
    }
    _sourceNameToJavaSource = sourceNameToJavaSource;
  }

  public InputStream getInputStream(String sourceName) throws IOException {
    String source = (String)_sourceNameToJavaSource.get(sourceName);
    if(source == null) {
      throw new IOException("unknown source: "+source);
    } else {
      return new ByteArrayInputStream(source.getBytes());
    }
  }
  
  /**
   * Runtime exception as this will normally be created where it is
   * obvious whether the code is right or wrong, not dependent on
   * outside factors.
   */
  public static class MapSourceReaderException extends RuntimeException {
    private MapSourceReaderException(String s) {
      super(s);
    }
  }

}// MapSourceReader
