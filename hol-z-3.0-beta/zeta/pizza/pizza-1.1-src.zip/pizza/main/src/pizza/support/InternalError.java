/**
 * Copyright (C) 1996-2001 Martin Odersky.
 * This software is distributed under the Artistic License. See 
 * artistic.html or artistic.txt which came with this distribution.
 */

package pizza.support;

public class InternalError extends Error {}
