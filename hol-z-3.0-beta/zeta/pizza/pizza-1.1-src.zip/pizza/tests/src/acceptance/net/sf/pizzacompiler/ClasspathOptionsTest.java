package net.sf.pizzacompiler;

/**
 * $Id: ClasspathOptionsTest.java,v 1.1 2001/10/31 15:45:16 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Wed Oct 31 14:42:09 2001
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import junit.framework.TestCase;

public class ClasspathOptionsTest extends TestCase {
  public ClasspathOptionsTest(String s){
    super(s);
  }
  
  // test for bug id 476765
  public void testUserClasspath() throws IOException, InterruptedException {
    // make two test files as specified
    File directory = CompilerTestMethods.makeTempDirectory();
    try {
      final String CLASS1 = "Test1";
      final String CLASS2 = "Test2";
      File class1src = new File(directory, CLASS1+".java");
      File class2src = new File(directory, CLASS2+".java");
      FileWriter writer = new FileWriter(class1src);
      writer.write("public class "+CLASS1+" {public "+CLASS1+"() {} }\n");
      writer.close();
      writer = new FileWriter(class2src);
      writer.write("public class "+CLASS2+" {public "+CLASS2+"() {"+CLASS1+" test = new "+CLASS1+"();} }\n");
      writer.close();

      // try and compile 1
      assertEquals("", CompilerTestMethods.compilerOutput(class1src, new String[0]));

      // compile 2 with a user classpath
      assertEquals("", CompilerTestMethods.compilerOutputForked(new String[]{ "-classpath", directory.getPath(), class2src.getPath()}));
      
      // delete the files
    } finally {
      CompilerTestMethods.recursivelyDeleteDir(directory);
    }
  }
}// ClasspathOptionsTest
