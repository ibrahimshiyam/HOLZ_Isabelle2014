package net.sf.pizzacompiler;

/**
 * $Id: CompilerMessagesTest.java,v 1.10 2002/01/04 09:16:39 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Aug 30 11:57:47 2001
 */

import java.io.File;
import java.io.IOException;
import junit.framework.*;

import net.sf.pizzacompiler.compiler.ErrorMessage;
import net.sf.pizzacompiler.compiler.Main;
import net.sf.pizzacompiler.compiler.Position;
import net.sf.pizzacompiler.compiler.Report;
import net.sf.pizzacompiler.compiler.WarningMessage;

public class CompilerMessagesTest extends TestCase {
  public CompilerMessagesTest(String s) {
    super(s);
  }

  //
  // actual tests
  //

  public void testHelpMessage() throws IOException {
    assertEquals("Usage: pc [ options ] file[s]\n\nwhere options include:\n"+
		 "  -classpath pathname     use given classpath\n"+
		 "  -bootclasspath pathname use given boot classpath\n"+
		 "  -d filename             redirect classfile output\n"+
		 "  -experimental           enable experimental features\n"+
		 "  -g                      include debug information\n"+
		 "  -java                   accept only standard Java input\n"+
		 "  -nowarn                 suppress warning messages\n"+
		 "  -pizza                  accept standard Pizza input\n"+
		 "  -printsearch            print information where classfiles are searched\n"+
		 "  -prompt                 stop after each error\n"+
		 "  -s                      emit java sources instead of classfiles\n"+
		 "  -scramble               scramble private identifiers in bytecode\n"+
		 "  -scrambleall            scramble package visible identifiers in bytecode\n"+
		 "  -source <release>       provide source compatibility with specified release\n"+
		 "  -switchcheck            warn about fall-through in switches\n"+
		 "  -target <release>       generate class files for specific VM version\n"+
		 "  -verbose                print detailed log\n"+
		 "  -version                version information\n"+
		 "  -pizzadoc               run pizzadoc\n\n",
		 CompilerTestMethods.collectOutput(new Runnable() {
		     public void run() {
		       try {
			 Main.main(new String[0]);
		       } catch(SecurityException ex) {
		       } catch(Throwable ex) {
			 ex.printStackTrace();
		       }
		     }
		   }));
  }

  public void testGenerateSourceCodeOverwriteError() throws IOException {
    testWarning(this, "APizzaClassTestCode.java", new Position(11, 8), "error writing source; cannot overwrite input file "+CompilerTestMethods.FILE, false, new String []{"-s","-pizza"});
  }

  public void testEnclosingClassOfInnerClassError() throws IOException {
    testWarning(this, "InnerEnclosingScopeTestCode.java", new Position(13,22),
		"enclosing class InnerEnclosingScopeTestCode.AnotherClass of class InnerEnclosingScopeTestCode.AnotherClass.InnerClass is not in scope", 
		false);
  }

  public void testDeprecatedWarning() throws IOException {
    testWarning(this, "DeprecatedTestCode2.java", new Position(13, 39), 
		"variable foo in class DeprecatedTestCode1 has been deprecated",
		true);
  }

  public void testCaseFallThroughWarning() throws IOException {
    String SOURCE = "CaseFallThroughTestCode.java";
    testNoErrors(this, SOURCE, new String[0]);
    testWarning(this, SOURCE, new Position(14, 5), 
		"possible fall-through from case", 
		true, new String[]{"-switchcheck"});
  }

  public void testUnreachableCodeWarning() throws IOException {
    testWarning(this, "UnreachableCodeTestCode.java", new Position(14, 5), 
		"statement is unreachable", true); 
  }

  //
  // helper code for tests
  //

  public void testNoErrors(Object caller, String source, 
			   String [] compileArgs) throws IOException {
    File file = CompilerTestMethods.findTestFile(caller, source);
    CompilerTestMethods.assertStringEquals("", CompilerTestMethods.compilerOutput(file, compileArgs));
  }

  private void testWarning(Object caller, String source, Position pos, 
			   String message, boolean isWarning) 
    throws IOException {
    testWarning(caller, source, pos, message, isWarning, new String [0]);
  }

  private void testWarning(Object caller, String source, Position pos,
			   String message, boolean isWarning, 
			   String [] compilerArgs) throws IOException {
    assertTrue("Not a .java or .pizza file", 
	       source.endsWith(".pizza") || source.endsWith(".java"));
    File file = CompilerTestMethods.findTestFile(caller, source);
    String absoluteSource = file.getAbsolutePath();
    ErrorMessage messageObj = 
      isWarning ? new WarningMessage(absoluteSource, pos, message) : 
      new ErrorMessage(absoluteSource, pos, message);
    String messageCount = isWarning ? "\n1 warning\n" : "\n1 error\n";

    CompilerTestMethods.assertStringEquals(CompilerTestMethods.expandMacros(messageObj.toString()+'\n'+Report.makeSourceDisplay(absoluteSource, pos)+messageCount, file),
		       CompilerTestMethods.compilerOutput(file, compilerArgs));
  }

}// CompilerMessagesTest
