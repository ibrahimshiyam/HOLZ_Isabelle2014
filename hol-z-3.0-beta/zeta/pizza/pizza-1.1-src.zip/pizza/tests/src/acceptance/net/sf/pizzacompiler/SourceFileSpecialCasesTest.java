package net.sf.pizzacompiler;

/**
 * $Id: SourceFileSpecialCasesTest.java,v 1.1 2001/09/03 16:04:33 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 16:26:13 2001
 */
import junit.framework.*;

import java.util.*;
import net.sf.pizzacompiler.compiler.MapSourceReader;

public class SourceFileSpecialCasesTest extends TestCase {
  public SourceFileSpecialCasesTest(String s){
    super(s);
  }
  
  public void testCompilesFileWithNoCarriageReturn() {
    final String SOURCE_NAME = "Foo.java";
    final String SOURCE_CODE = "public class Foo {}";
    assertEquals("",
		 CompilerTestMethods.compilerOutput(SOURCE_NAME, new MapSourceReader(Collections.singletonMap(SOURCE_NAME, SOURCE_CODE))));
  }
}// SourceFileSpecialCasesTest
