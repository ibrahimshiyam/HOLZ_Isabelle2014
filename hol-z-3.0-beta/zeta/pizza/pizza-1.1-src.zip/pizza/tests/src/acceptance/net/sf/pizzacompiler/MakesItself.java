package net.sf.pizzacompiler;

/**
 * $Id: MakesItself.java,v 1.3 2001/09/13 16:54:34 nfortescue Exp $ 
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See 
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Wed Aug 29 14:46:24 2001
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import junit.framework.*;
import net.sf.pizzacompiler.compiler.Main;

public class MakesItself extends TestCase {
  public MakesItself(String s) {
    super(s);
  }
  
  public void testMakesItself() throws Throwable {
    // make a temporary directory
    File selfCompiled = CompilerTestMethods.makeTempDirectory();
    try {
      ArrayList args = new ArrayList();
      args.add("-d");
      args.add(selfCompiled.getAbsolutePath());
      args.addAll(getAllSourceFiles());
      // make this from the source to the temporary directory
      assertEquals(0, CompilerTestMethods.getCompilerExitStatus((String [])args.toArray(new String[args.size()])));
      // check that the version we just made at least seems to work
      checkPizzaWorks(selfCompiled);
    } finally {
      CompilerTestMethods.recursivelyDeleteDir(selfCompiled);
    }
  }

  private void checkPizzaWorks(File pizzaClasses) throws IOException, InterruptedException  {
    File testDir = CompilerTestMethods.makeTempDirectory();
    final String CLASS_NAME = "Test";
    File aJavaFile = new File(testDir, CLASS_NAME+".java");
    final int RET_VALUE = 42;
    writeJavaMainReturning(aJavaFile, CLASS_NAME, RET_VALUE);
    try {
      Runtime runtime = Runtime.getRuntime();
      Process process = runtime.exec(new String[]{"java","-classpath",pizzaClasses.getAbsolutePath(),"net.sf.pizzacompiler.compiler.Main","-d",testDir.getAbsolutePath(),aJavaFile.getAbsolutePath()});
      process.waitFor();
      assertEquals(0, process.exitValue());

      process = runtime.exec(new String[]{"java","-classpath",testDir.getAbsolutePath(), CLASS_NAME});
      process.waitFor();
      assertEquals(RET_VALUE, process.exitValue());
    } finally {
      CompilerTestMethods.recursivelyDeleteDir(testDir);
    }
  }

  private void writeJavaMainReturning(File javaFile, String className, 
				      int retvalue) throws IOException {
    FileWriter writer = new FileWriter(javaFile);
    try {
      writer.write("public class ");
      writer.write(className);
      writer.write("{\n public static void main(String [] args) {\n  System.exit(");
      writer.write(Integer.toString(retvalue));
      writer.write(");\n }\n}\n");
    } finally {
      writer.close();
    }
  }

  private ArrayList getAllSourceFiles() throws IOException {
    ArrayList result = new ArrayList();
    // this probably shouldn't be hardcoded, but I can't think of a better way
    recursivelyFindPizzaAndJava(new File("main/src"),result);
    return result;
  }

  private void recursivelyFindPizzaAndJava(File directory, 
					   ArrayList accumulator) 
    throws IOException {

    File [] contents = directory.listFiles();
    for(int i=0; i<contents.length; i++) {
      if(contents[i].isDirectory()) {
	// this definitely shouldn't be hardcoded. Oh well.
	if(!"ant".equals(contents[i].getName())) {
	  recursivelyFindPizzaAndJava(contents[i], accumulator);
	}
      } else {
	if(contents[i].toString().endsWith(".java") ||
	   contents[i].toString().endsWith(".pizza")) {
	  accumulator.add(contents[i].getAbsolutePath());
	}
      }
    }
  }
}// MakesItself
