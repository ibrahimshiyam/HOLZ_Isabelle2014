package net.sf.pizzacompiler;

/**
 * $Id: AllAcceptanceTests.java,v 1.7 2001/10/31 15:45:16 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See 
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Wed Aug 29 14:34:24 2001
 */

import junit.framework.*;

public class AllAcceptanceTests extends TestSuite {
  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTest(new TestSuite(ClassAndSourceOutputTests.class));
    suite.addTest(new TestSuite(ClasspathOptionsTest.class));
    suite.addTest(new TestSuite(EmbeddedTest.class));
    suite.addTest(new TestSuite(MakesItself.class));
    suite.addTest(new TestSuite(CompilerMessagesTest.class));
    suite.addTest(new TestSuite(SourceFileSpecialCasesTest.class));
    return suite;
  }
}// AllAcceptanceTests
