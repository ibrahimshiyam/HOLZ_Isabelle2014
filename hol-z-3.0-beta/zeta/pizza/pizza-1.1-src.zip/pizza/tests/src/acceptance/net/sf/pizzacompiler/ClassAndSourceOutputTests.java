package net.sf.pizzacompiler;

/**
 * $Id: ClassAndSourceOutputTests.java,v 1.2 2001/09/14 13:12:55 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Sep 13 15:36:05 2001
 */

import junit.framework.*;
import java.io.File;
import java.io.IOException;

public class ClassAndSourceOutputTests extends TestCase {
  public ClassAndSourceOutputTests(String s) {
    super(s);
  }

  final String GOOD_FILE = "APizzaClassTestCode.java";
  final String WARNING_FILE = "UnreachableCodeTestCode.java";
  final String BAD_FILE = "UnreachableCodeTestCode.java";

  public void testClassesGetWrittenIfWarningOccurs() throws IOException {
    testNFilesGetWritten(WARNING_FILE, new String[0], 1);
  }
  public void testClassesDontGetWrittenIfErrorOccurs() throws IOException {
    testNFilesGetWritten(BAD_FILE, new String[0], 1);
  }
  
  public void testClassesWrittenToChosenDir() throws IOException {
    testNFilesGetWritten(GOOD_FILE, new String[0], 1);
  }

  public void testSourceWrittenToChosenDir() throws IOException {
    testNFilesGetWritten(GOOD_FILE, new String[]{"-s"}, 1);
  }

  private void testNFilesGetWritten(String filename, String [] args, 
				    int nrFiles) 
    throws IOException {

    File tempDir = CompilerTestMethods.makeTempDirectory();
    try {
      assertEquals(0, tempDir.listFiles().length);
      File source = 
	CompilerTestMethods.findTestFile(this, filename);
      final String [] myArgs = 
	new String[]{"-pizza", "-d", tempDir.getAbsolutePath()};
      String [] allArgs = new String[args.length+myArgs.length];
      System.arraycopy(args, 0, allArgs, 0, args.length);
      System.arraycopy(myArgs, 0, allArgs, args.length, myArgs.length);
      CompilerTestMethods.compilerOutput(source, allArgs);

      File [] files = tempDir.listFiles();
      assertEquals(files.length == 0 ? "No files" : "first was "+files[0],
		   nrFiles, files.length);
    } finally {
      CompilerTestMethods.recursivelyDeleteDir(tempDir);
    }
  }

}// ClassAndSourceOutputTests
