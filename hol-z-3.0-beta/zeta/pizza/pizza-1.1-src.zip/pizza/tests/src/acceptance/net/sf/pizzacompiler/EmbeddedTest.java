package net.sf.pizzacompiler;

/**
 * $Id: EmbeddedTest.java,v 1.3 2001/09/19 15:17:23 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 17 14:40:44 2001
 */

import junit.framework.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.*;

import net.sf.pizzacompiler.compiler.ByteArrayClassLoader;
import net.sf.pizzacompiler.compiler.ByteArrayCompilerOutput;
import net.sf.pizzacompiler.compiler.ClassReader;
import net.sf.pizzacompiler.compiler.CompilerOutput;
import net.sf.pizzacompiler.compiler.Main;
import net.sf.pizzacompiler.compiler.MapSourceReader;
import net.sf.pizzacompiler.compiler.Report;
import net.sf.pizzacompiler.compiler.SourceReader;

public class EmbeddedTest extends TestCase {
  public EmbeddedTest(String s) {
    super(s);
  }
  
  public void testEmbeddedCompiler() throws ClassNotFoundException, IllegalAccessException, InstantiationException {
    final String CLASS_NAME = "Foo";
    int EXPECTED = 42;
    ByteArrayCompilerOutput output = 
      embeddedCompile(CLASS_NAME,
		      "public int hashCode(){return "+EXPECTED+";}", null);
    ClassLoader cl = 
      new ByteArrayClassLoader(ClassLoader.getSystemClassLoader(), 
			       output.getBytecode());
    Class clazz = cl.loadClass(CLASS_NAME);
    Object instance = clazz.newInstance();
    assertEquals(EXPECTED, instance.hashCode());
  }

  public void testEmbeddedMessages() {
    Runnable compileBad = new Runnable() {
	public void run() {
	  embeddedCompile("Foo","public int hashCode() {", null);
	}
      };
    assertEquals("", CompilerTestMethods.collectOutput(compileBad));
    assertEquals(1, Report.getErrorsAndWarnings().size());
  }

  public void testOverrideClassReader() {
    Runnable compileOk = new Runnable() {
	public void run() {
	  embeddedCompile("Foo","public String toString() {return \"\";}", new ClassReader() {
	      protected InputStream find(String name) {
		name = name.replace(File.separatorChar, '/');
		return ClassLoader.getSystemResourceAsStream(name);
	      }
	    });
	}
      };
    assertEquals("", CompilerTestMethods.collectOutput(compileOk));
    assertEquals(Report.getErrorsAndWarnings().toString(), 
		 0, 
		 Report.getErrorsAndWarnings().size());
    // do it twice to check for static errors
    assertEquals("", CompilerTestMethods.collectOutput(compileOk));
    assertEquals(Report.getErrorsAndWarnings().toString(), 
		 0, 
		 Report.getErrorsAndWarnings().size());
  }

  private ByteArrayCompilerOutput embeddedCompile(String className,
						  String classContents,
						  ClassReader classReader) {
    ByteArrayCompilerOutput output = new ByteArrayCompilerOutput();
    Map sourceMap = Collections.singletonMap(className+".java", "public class "+className+"{ "+classContents+" } ");
    Main.init();
    if(classReader != null) {
      Main.setClassReader(classReader);
    }
    Main.compile(new String[]{className+".java"},
		 new MapSourceReader(sourceMap), 
		 output,
		 new NullPrintStream());
    return output;
  }

  private static class NullPrintStream extends PrintStream {
    public NullPrintStream() {super(new NullOutputStream());}
  }
  private static class NullOutputStream extends OutputStream {
    public void write(int b) {}
  }
}// EmbeddedTest
