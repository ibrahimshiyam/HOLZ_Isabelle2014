package net.sf.pizzacompiler;

/**
 * $Id: CompilerTestMethods.java,v 1.6 2001/10/31 15:45:16 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 16:28:44 2001
 */

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.util.*;
import java.security.Permission;

import net.sf.pizzacompiler.compiler.FileCompilerOutput;
import net.sf.pizzacompiler.compiler.Main;
import net.sf.pizzacompiler.compiler.SourceReader;

import junit.framework.Assert;

public abstract class CompilerTestMethods {
  public static final String FILE = "${FILE}";

  /**
   * Make a new temporary directory
   */
  public static File makeTempDirectory() throws IOException {
    File tmpdir = getValidTempFileName();
    Assert.assertTrue(tmpdir.mkdir());
    return tmpdir;
  }

  private static File getValidTempFileName() throws IOException {
    File tmpFile = File.createTempFile("pizzatest","directory");
    tmpFile.delete();
    return tmpFile.getAbsoluteFile();
  }

  /**
   * delete everything in a directory ... dangerous, be careful
   */
  public static void recursivelyDeleteDir(File dir) throws IOException {
    Assert.assertTrue(dir.isDirectory());
    File [] contents = dir.listFiles();
    for(int i=0; i<contents.length; i++) {
      if(contents[i].isDirectory()) {
	recursivelyDeleteDir(contents[i]);
      } else {
	contents[i].delete();
      }
    }
    dir.delete();
  }

  
  public static String getPackageNameFromClass(String className) {
    int endIndex = className.lastIndexOf('.');
    if(endIndex == -1) {
      endIndex = 0;
    }
    return className.substring(0, endIndex);
  }

  public static File findTestFile(Object caller, String filename) 
    throws IOException {

    String packageName = getPackageNameFromClass(caller.getClass().getName());
    char fileSep = System.getProperty("file.separator").charAt(0);
    String resourceName = packageName.replace('.', fileSep)+fileSep+filename;
    URL resource = ClassLoader.getSystemResource(resourceName);
    Assert.assertTrue("could not find test file "+resourceName, resource != null);
    Assert.assertEquals("resource was not a file", "file", resource.getProtocol());
    return new File(resource.getFile());
  }

  public static String compilerOutput(final String sourceToCompile, 
				      final SourceReader whereItComesFrom) {
    return collectOutput(new Runnable() {
	public void run() {
	  Main.compile(new String[]{sourceToCompile}, whereItComesFrom, new FileCompilerOutput(null), null);
	}
      });
  }

  // adds the directory with the file to compile to the classpath
  public static String compilerOutput(final File fileToCompile, 
				      final String [] compileArgs) {
    return compilerOutput(fileToCompile, compileArgs, fileToCompile.getParent());
  }

  public static String compilerOutput(final File fileToCompile, 
				      final String [] compileArgs,
				      String classpath) {
   String [] myArgs = 
      new String[]{"-classpath", classpath, fileToCompile.getAbsolutePath()};
   final String [] args = new String[compileArgs.length+myArgs.length];
   System.arraycopy(compileArgs, 0, args, 0, compileArgs.length);
   System.arraycopy(myArgs, 0, args, compileArgs.length, myArgs.length);
   return collectOutput(new Runnable() {
       public void run() {
	 try {
	   try {
	     Main.main(args);
	   } catch(SecurityException ex) { 
	     // this comes from not being able to exit
	   }
	 } catch(Throwable e) {
	   throw new RuntimeException(e.getMessage());
	 }
       }
     });
  }

  public static String compilerOutputForked(String [] args) throws IOException, InterruptedException {
    final String [] defaultargs = {"java", "-jar", "pizza.jar"};
    String [] allArgs = new String[args.length+defaultargs.length];
    System.arraycopy(defaultargs, 0, allArgs, 0, defaultargs.length);
    System.arraycopy(args, 0, allArgs, defaultargs.length, args.length);
    Process process = Runtime.getRuntime().exec(allArgs);
    // collect the output
    final InputStream out = process.getInputStream();
    final InputStream err = process.getErrorStream();
    final StringBuffer output = new StringBuffer();
    new Thread(new Runnable() {
	public void run() {
	  try {
	    for(int c=out.read(); c!=-1; c=out.read()) {
	      output.append((char)c);
	    }
	  } catch(IOException ex) {
	    ex.printStackTrace();
	  }
	}
      }).start();
    new Thread(new Runnable() {
	public void run() {
	  try {
	    for(int c=err.read(); c!=-1; c=err.read()) {
	      output.append((char)c);
	    }
	  } catch(IOException ex) {
	    ex.printStackTrace();
	  }
	}
      }).start();
    // wait for all output
    process.waitFor();
    return output.toString();
  }

  public static int getCompilerExitStatus(String [] args) throws Throwable {
    SecurityManager oldManager = System.getSecurityManager();
    PrintStream oldOut = System.out;
    try {
      System.setOut(new PrintStream(new ByteArrayOutputStream()));
      ExitCatchingSecurityManager exitTrapper = 
	new ExitCatchingSecurityManager();
      System.setSecurityManager(exitTrapper);
      try {
	Main.main(args);
	Assert.fail("should have tried to exit");
      } catch(SecurityException e) {
      }
      return exitTrapper.getExitStatus();
    } finally {
      System.setOut(oldOut);
      System.setSecurityManager(oldManager);
    }
  }

  public static String collectOutput(Runnable runner) {
    ByteArrayOutputStream newOutBytes = new ByteArrayOutputStream();
    PrintStream newOut = new PrintStream(newOutBytes);
    PrintStream oldOut = System.out;
    PrintStream oldErr = System.err;
    SecurityManager oldManager = System.getSecurityManager();
    System.setSecurityManager(new ExitCatchingSecurityManager());
    try {
      setOutAndErr(newOut, newOut);
      runner.run();
      return replaceString(new String(newOutBytes.toByteArray()), 
			   "\r\n","\n");
    } finally {
      setOutAndErr(oldOut, oldErr);
      System.setSecurityManager(oldManager);
      newOut.close();
    }
  }

  private static void setOutAndErr(PrintStream out, PrintStream err) {
    System.setOut(out);
    System.setErr(err);
  }

  public static String expandMacros(String message, File file) {
    return replaceString(message, FILE, file.getAbsolutePath());
  }

  private static String replaceString(String source, String original, 
			       String replacement) {
    StringBuffer result = new StringBuffer(source);
    int endIndex = source.length();
    for(int macroIndex = source.lastIndexOf(original, endIndex); 
	macroIndex != -1;
	macroIndex = source.lastIndexOf(original, endIndex)) {
      result.replace(macroIndex, macroIndex+original.length(), replacement);
      endIndex = macroIndex -1;
    }
    return result.toString();
  }

  public static void assertStringEquals(String s1, String s2) {
    Assert.assertEquals(summariseStringDifference(s1, s2), s1, s2);
  }

  private static String summariseStringDifference(String s1, String s2) {
    StringBuffer message = new StringBuffer();
    message.append("expected length ");
    message.append(s1.length());
    message.append("but was ");
    message.append(s2.length());
    message.append("\n");
    int diffIndex = findFirstDifference(s1, s2);
    if(diffIndex != s1.length()) {
      message.append("Difference at position ");
      message.append(diffIndex);
      message.append(", expected ");
      message.append(showWhiteSpace(s1.substring(diffIndex, min(diffIndex+5,s1.length()))));
      message.append("but was ");
      message.append(showWhiteSpace(s2.substring(diffIndex, min(diffIndex+5,s2.length()))));
    }
    return message.toString();
  }

  private static String showWhiteSpace(String s) {
    String result = replaceString(s, "\t", "\\t");
    result = replaceString(result, "\n", "\\n");
    result = replaceString(result, "\r", "\\r");
    result = replaceString(result, " ", "\\s");
    result = replaceString(result, " ", "\\s");
    return result;
  }

  private static int findFirstDifference(String s1, String s2) {
    int result = 0;
    while(result < s1.length() && 
	  result < s2.length() &&
	  s1.charAt(result) == s2.charAt(result)) {
      result++;
    }
    return result;
  }

  private static int min(int a, int b) {
    return a < b ? a : b;
  }

  private static class ExitCatchingSecurityManager extends SecurityManager {
    int _lastExitStatus;
    public void checkPermission(Permission perm) {
    }
    public void checkPermission(Permission perm, Object context) {
    }
    public void checkExit(int status) {
      _lastExitStatus = status;
      throw new SecurityException("we don't allow exits");
    }
    public int getExitStatus() {
      return _lastExitStatus;
    }
  }

} // CompilerTestMethods
