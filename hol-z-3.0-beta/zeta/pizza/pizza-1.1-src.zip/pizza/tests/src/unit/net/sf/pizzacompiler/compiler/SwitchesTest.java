package net.sf.pizzacompiler.compiler;

/**
 * $Id: SwitchesTest.java,v 1.2 2001/09/03 14:19:15 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Aug 30 15:07:45 2001
 */
import junit.framework.*;

public class SwitchesTest extends TestCase {
  public SwitchesTest(String s){
    super(s);
  }
  
  public void testDefaultSettings() {
    assertTrue(!Switches.verbose);
    assertTrue(!Switches.scramble);
    assertTrue(!Switches.scrambleAll);
    assertTrue(!Switches.symOnly);
    assertTrue(!Switches.emitSource);
    assertTrue(!Switches.nowarn);

    assertTrue(!Switches.promptOnError);
    assertTrue(!Switches.experimental);
    assertTrue(!Switches.switchCheck);
    assertTrue(!Switches.optimize);

    assertTrue(!Switches.moreInfo);
    assertTrue(!Switches.printTree);
    assertTrue(!Switches.printSearch);
    assertTrue(!Switches.debugInfo);

    assertTrue(!Switches.diagnostics);

    assertTrue(Switches.classesNest);

    assertTrue(!Switches.pizza);

    assertTrue(Switches.errorsPossible);

    assertTrue(Switches.checks);
    assertTrue(!Switches.checkClassFile);
    assertTrue(!Switches.debug);

    assertTrue(!Switches.readAllOfClassFile);

    assertTrue(!Switches.pizzadoc);
 }

  public void testReset() {
    Switches.pizzadoc = true;
    Switches.resetToDefaults();
    testDefaultSettings();
  }

}// SwitchesTest
