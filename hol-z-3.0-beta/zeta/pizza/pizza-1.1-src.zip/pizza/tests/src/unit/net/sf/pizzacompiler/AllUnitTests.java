package net.sf.pizzacompiler;

/**
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See 
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Wed Aug 29 14:34:24 2001
 */

import junit.framework.*;

public class AllUnitTests extends TestSuite {
  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTest(net.sf.pizzacompiler.compiler.AllUnitTests.suite());
    suite.addTest(new TestSuite(net.sf.pizzacompiler.util.HashtableTest.class));
    return suite;
  }
}// AllUnitTests
