package net.sf.pizzacompiler.compiler;

/**
 * $Id: MapSourceReaderTest.java,v 1.1 2001/09/03 16:04:33 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 15:23:08 2001
 */

import junit.framework.*;
import java.io.IOException;
import java.util.*;

public class MapSourceReaderTest extends TestCase {
  public MapSourceReaderTest(String s) {
    super(s);
  }
  
  public void testBadMapThrowsConstructorError() {
    try {
      new MapSourceReader(Collections.singletonMap("foo", new Object()));
      fail("Map which isn't String to String should throw exception");
    } catch (MapSourceReader.MapSourceReaderException ex) {
    }
  }

  public void testReadAll() throws IOException {
    String NAME = "foo";
    String VALUE = "bar";
    MapSourceReader source = 
      new MapSourceReader(Collections.singletonMap(NAME, VALUE));
    byte [] read = source.readAll(NAME);
    byte [] expected = VALUE.getBytes();
    assertEquals(expected.length, read.length);
    for(int i=0; i<read.length; i++) {
      assertEquals(Integer.toString(i), expected[i], read[i]); 
    }
  }

  public void testGetMissing() {
    try {
      new MapSourceReader(Collections.EMPTY_MAP).getInputStream("foo");
      fail("should throw IOException for missing source");
    } catch(IOException ex) {
    }
  }

}// MapSourceReaderTest
