package net.sf.pizzacompiler.compiler;

/**
 * $Id: AllUnitTests.java,v 1.5 2001/10/31 16:38:59 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Fri Sep 14 10:22:42 2001
 */

import junit.framework.*;

public class AllUnitTests extends TestSuite {
  
  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTest(new TestSuite(BasicTest.class));
    suite.addTest(new TestSuite(ClassReaderTest.class));
    suite.addTest(new TestSuite(ErrorMessageTest.class));
    suite.addTest(new TestSuite(FileCompilerOutputTest.class));
    suite.addTest(new TestSuite(MainTest.class));
    suite.addTest(new TestSuite(MapSourceReaderTest.class));
    suite.addTest(new TestSuite(PositionTest.class));
    suite.addTest(new TestSuite(ReportTest.class));
    suite.addTest(new TestSuite(SwitchesTest.class));
    suite.addTest(new TestSuite(TypeTest.class));
    suite.addTest(new TestSuite(ZipFileDirectoryTest.class));
    return suite;
  }
}// AllUnitTests
