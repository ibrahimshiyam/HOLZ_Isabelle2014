package net.sf.pizzacompiler.compiler;

/**
 * $Id: MainTest.java,v 1.1 2001/09/13 16:54:37 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Sep 13 16:10:04 2001
 */

import junit.framework.*;

import net.sf.pizzacompiler.CompilerTestMethods;

public class MainTest extends TestCase {
  public MainTest (String s){
    super(s);
  }
  
  public void testSuccessfulMainExitsWithZero() throws Throwable {
    assertEquals(0,CompilerTestMethods.getCompilerExitStatus(new String[] {
      CompilerTestMethods.findTestFile(this, "Good.java").getAbsolutePath(),
    }));
  }

  public void testNoArgMainExitsWithNonZero() throws Throwable {
    assertEquals(1,CompilerTestMethods.getCompilerExitStatus(new String[0]));
  }

  public void testErroneousMainExitsWithNonZero() throws Throwable {
    assertEquals(1,CompilerTestMethods.getCompilerExitStatus(new String[] {
      CompilerTestMethods.findTestFile(this, "Bad.java").getAbsolutePath(),
    }));
  }

}// MainTest
