package net.sf.pizzacompiler.compiler;

/**
 * $Id: ErrorMessageTest.java,v 1.3 2001/09/14 15:26:08 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 11:36:54 2001
 */

import junit.framework.*;

public class ErrorMessageTest extends TestCase {
  private static final Position POS =new Position(1,2);
  private static final Position DIFF_POS =new Position(1,3);
  private static final String SOURCE = "foo.java";
  private static final String MESSAGE = "message";
  private static final String DIFF_MESSAGE = "another message";

  public ErrorMessageTest(String s) {
    super(s);
  }

  public void testEquals() {
    assertEquals(makeOne(), makeOne());
    assertTrue(!makeOne().equals(makeAnotherDifferentPosition()));
  }
  public void testMessageDoesntAffectEquals() {
    assertEquals(makeOne(), makeAnotherDifferentMessage());
  }
  public void testMessageDoesntAffectHashCode() {
    assertEquals(makeOne().hashCode(), 
		 makeAnotherDifferentMessage().hashCode());
  }
  public void testHashCode() {
    assertEquals(makeOne().hashCode(), makeOne().hashCode());
  }

  public void testIsError() {
    assertTrue(makeOne().isError());
    assertTrue(!new WarningMessage(SOURCE, POS, MESSAGE).isError());
  }

  private ErrorMessage makeOne() {
    return new ErrorMessage(SOURCE, POS, MESSAGE);
  }
  private ErrorMessage makeAnotherDifferentMessage() {
    return new ErrorMessage(SOURCE, POS, DIFF_MESSAGE);
  }

  private ErrorMessage makeAnotherDifferentPosition() {
    return new ErrorMessage(SOURCE, DIFF_POS, MESSAGE);
  }

  public void testNoPosToString() {
    String message = "foo";
    assertEquals("error: "+message,
		 new ErrorMessage("bar", Position.NO_POS, message).toString());
  }

  public void testErrorToString() {
    String message = "enclosing class InnerEnclosingScopeTestCode.AnotherClass of class InnerEnclosingScopeTestCode.AnotherClass.InnerClass is not in scope";
    assertEquals("InnerEnclosingScopeTestCode.java:13: "+message, 
		 new ErrorMessage("InnerEnclosingScopeTestCode.java", new Position(13,22), message).toString()
		   );
  }

  public void testWarningToString() {
    String message = "variable foo in class DeprecatedTestCode1 has been deprecated";
    assertEquals("DeprecatedTestCode2.java:13: warning: "+message,
		 new WarningMessage("DeprecatedTestCode2.java", 
				    new Position(13,39),
				    message).toString()
		   );
  }

}// ErrorMessageTest
