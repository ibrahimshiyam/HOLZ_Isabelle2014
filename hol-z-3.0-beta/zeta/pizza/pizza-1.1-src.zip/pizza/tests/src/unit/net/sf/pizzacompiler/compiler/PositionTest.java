package net.sf.pizzacompiler.compiler;

/**
 * $Id: PositionTest.java,v 1.2 2001/09/14 15:26:08 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 10:39:03 2001
 */

import junit.framework.*;

public class PositionTest extends TestCase {
  public PositionTest (String s){
    super(s);
  }

  public void testPosition() throws Position.PositionException {
    int LINE = 1;
    int COLUMN = 2;
    assertEquals(LINE, (new Position(LINE, COLUMN)).getLine());
    assertEquals(COLUMN, (new Position(LINE, COLUMN)).getColumn());
  }

  public void testPositionForInt() throws Position.PositionException {
    assertEquals(Position.NO_POS, Position.makePosition(Position.NOPOS));
    assertEquals(Position.makePosition(Position.makePos(1,2)), 
		 new Position(1,2));
  }

  public void testBadConstructor() {
    try {
      new Position(0,1);
      fail("bad position");
    } catch (Position.PositionException ex) {
    }
    try {
      new Position(1,0);
      fail("bad position");
    } catch (Position.PositionException ex) {
    }
  }

  public void testNoPos() {
    try {
      Position.NO_POS.getLine();
      fail("bad position");
    } catch (Position.PositionException ex) {
    }   
    try {
      Position.NO_POS.getColumn();
      fail("bad position");
    } catch (Position.PositionException ex) {
    }   
  }

  public void testEquals() throws Position.PositionException {
    assertEquals(new Position(1,1), new Position(1,1));
    assertTrue(!new Position(1,1).equals(new Position(1,2)));
    assertEquals(new Position(1,1).hashCode(), new Position(1,1).hashCode());
  }

  public void testIsValid() throws Position.PositionException {
    assertTrue(!Position.NO_POS.isValid());
    assertTrue(new Position(1,2).isValid());
  }

}// PositionTest
