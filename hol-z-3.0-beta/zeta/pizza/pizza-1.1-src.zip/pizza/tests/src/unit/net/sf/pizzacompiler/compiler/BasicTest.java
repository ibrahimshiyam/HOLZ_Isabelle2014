package net.sf.pizzacompiler.compiler;

/**
 * $Id: BasicTest.java,v 1.2 2001/09/14 11:08:04 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Aug 30 15:35:46 2001
 */
import junit.framework.*;

public class BasicTest extends TestCase {
  public BasicTest (String s){
    super(s);
  }

  // outDir has been remove from Basic so the old tests which were
  // here were redundant, and we have no more tests for this class
  // yet. Can you spare a test bro'?
  public void testNothing() {
  }

}// BasicTest
