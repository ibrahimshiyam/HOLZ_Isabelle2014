package net.sf.pizzacompiler.compiler;

/**
 * $Id: ZipFileDirectoryTest.java,v 1.1 2001/10/01 13:56:38 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Oct 01 13:30:37 2001
 */

import junit.framework.TestCase;

import net.sf.pizzacompiler.CompilerTestMethods;

import java.io.IOException;
import java.util.zip.ZipFile;

public class ZipFileDirectoryTest extends TestCase {
  public ZipFileDirectoryTest(String s) {
    super(s);
  }
  
  public void testListFiles() throws IOException {
    ZipFile zipfile = 
      new ZipFile(CompilerTestMethods.findTestFile(this, "sample.jar"));
    ZipFileDirectory directory = new ZipFileDirectory(zipfile);
    assertEquals(0, directory.listFiles("nofiles").length);
    assertEquals(1, directory.listFiles("onefile").length);
    assertEquals("file1", directory.listFiles("onefile")[0]);
    assertEquals(2, directory.listFiles("twofiles").length);
    assertEquals("file1", directory.listFiles("twofiles")[0]);
    assertEquals("file2", directory.listFiles("twofiles")[1]);
  }

}// ZipFileDirectoryTest
