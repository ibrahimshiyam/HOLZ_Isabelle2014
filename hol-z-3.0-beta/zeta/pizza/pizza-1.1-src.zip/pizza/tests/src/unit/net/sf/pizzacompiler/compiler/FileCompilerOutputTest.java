package net.sf.pizzacompiler.compiler;

/**
 * $Id: FileCompilerOutputTest.java,v 1.1 2001/09/14 11:08:04 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Fri Sep 14 09:39:24 2001
 */

import junit.framework.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;

import net.sf.pizzacompiler.CompilerTestMethods;

/**
 * Summarises the idea of writing Java source and class files to the
 * file system
 */

public class FileCompilerOutputTest extends TestCase {
  private static final String CLASS_NAME = "Foo";
  private File _tempDir;

  public FileCompilerOutputTest(String s) {
    super(s);
  }

  protected void setUp() throws IOException {
    _tempDir = CompilerTestMethods.makeTempDirectory();
  }

  protected void tearDown() throws IOException {
    CompilerTestMethods.recursivelyDeleteDir(_tempDir);
  }

  public void testGetClassOutputStream() throws IOException {
    testGetClassOutputStream(_tempDir, CLASS_NAME+".java", CLASS_NAME, 
			     new File(_tempDir,CLASS_NAME+".class"));
  }

  public void testGetSourceOutputStream() throws IOException {
    CompilerOutput written = new FileCompilerOutput(_tempDir);
    OutputStream os =
      written.getSourceOutputStream(CLASS_NAME+".pizza", CLASS_NAME, new MapSourceReader(Collections.EMPTY_MAP), Position.NOPOS);
    _checkOutputStreamIsFile(os, new File(_tempDir,CLASS_NAME+".java"));
  }

  public void testGetClassOutputStreamNoDirectory() throws IOException {
    testGetClassOutputStream(null, new File(_tempDir,CLASS_NAME+".java").toString(), CLASS_NAME, new File(_tempDir,CLASS_NAME+".class"));
  }
  
  public void testSubDirectoriesMade() throws IOException {
    final String PACKAGE = "wibble";
    testGetClassOutputStream(_tempDir, PACKAGE+"/"+CLASS_NAME+".java", PACKAGE+'.'+CLASS_NAME, new File(new File(_tempDir, PACKAGE),CLASS_NAME+".class"));
  }

  public void testConstructorNonExisitingDirectoryOk() {
    CompilerOutput written = 
      new FileCompilerOutput(new File(_tempDir, "wibble"));
  }

  private void testGetClassOutputStream(File dir,
					String sourceFile,
					String classFullName,
					File expectedFile) throws IOException {
    CompilerOutput written = new FileCompilerOutput(dir);
    OutputStream os =
      written.getClassOutputStream(sourceFile, classFullName);
    _checkOutputStreamIsFile(os, expectedFile);
  }

  private void _checkOutputStreamIsFile(OutputStream os, File file) 
    throws IOException {

    int VALUE = 42;
    int EOF = -1;
    
    try {
      os.write(VALUE);
    } finally {
      os.close();
    }
    assertTrue(file.exists());
    FileInputStream fis = new FileInputStream(file);
    try {
      assertEquals(VALUE, fis.read());
      assertEquals(EOF, fis.read());
    } finally {
      fis.close();
    }
  }

}// FileCompilerOutputTest
