/**
 * $Id: CaseFallThroughTestCode.java,v 1.1 2001/08/30 17:17:57 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Aug 30 18:01:06 2001
 */

public class CaseFallThroughTestCode {
  public CaseFallThroughTestCode(int i){
    switch(i) {
    case 1:
      int foo =1;
      // we should get a case fall through warning here
    case 2:
      int bar =1;
      break;
    }
  }
  
}// CaseFallThroughTestCode
