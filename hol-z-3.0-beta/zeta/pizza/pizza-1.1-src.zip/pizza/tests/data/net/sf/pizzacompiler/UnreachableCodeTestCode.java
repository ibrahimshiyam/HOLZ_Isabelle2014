/**
 * $Id: UnreachableCodeTestCode.java,v 1.1 2001/08/30 18:02:21 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Aug 30 18:56:29 2001
 */

public class UnreachableCodeTestCode {
  public UnreachableCodeTestCode (){
    return;
    return;
  }
  
}// UnreachableCodeTestCode
