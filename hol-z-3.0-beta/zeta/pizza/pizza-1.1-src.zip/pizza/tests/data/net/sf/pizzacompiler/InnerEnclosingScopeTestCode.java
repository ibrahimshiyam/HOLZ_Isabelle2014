/**
 * $Id: InnerEnclosingScopeTestCode.java,v 1.1 2001/09/03 09:29:49 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 09:54:30 2001
 */

public class InnerEnclosingScopeTestCode {
  public InnerEnclosingScopeTestCode() {
    Object foo = new AnotherClass.InnerClass();
  }
  
  /**
   * A class with a non-static inner class. We shouldn't be able to
   * construct the non-static inner class as it is not in scope.
   */
  private static class AnotherClass {
    public class InnerClass {
    }
  }

}// InnerEnclosingScopeTestCode
