/**
 * $Id: DeprecatedTestCode1.java,v 1.1 2001/08/30 16:37:38 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See 
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Aug 30 08:54:03 2001
 */


public class DeprecatedTestCode1 {
  /**
   * @deprecated Deprecated to test deprecation
   */
  public int foo;
}// DeprecatedTestCode1
