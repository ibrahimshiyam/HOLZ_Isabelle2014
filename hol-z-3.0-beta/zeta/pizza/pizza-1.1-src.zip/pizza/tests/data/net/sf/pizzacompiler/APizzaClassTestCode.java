/**
 * $Id: APizzaClassTestCode.java,v 1.1 2001/09/03 13:46:19 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Mon Sep 03 14:20:56 2001
 */

public class APizzaClassTestCode<A>{
  public APizzaClassTestCode (){
    
  }
  
}// APizzaClassTestCode
