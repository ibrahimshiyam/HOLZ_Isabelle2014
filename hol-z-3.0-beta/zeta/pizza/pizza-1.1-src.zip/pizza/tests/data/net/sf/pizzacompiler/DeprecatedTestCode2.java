/**
 * $Id: DeprecatedTestCode2.java,v 1.1 2001/08/30 16:37:38 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Aug 30 11:34:01 2001
 */

public class DeprecatedTestCode2 {
  public DeprecatedTestCode2 (){
    int i = new DeprecatedTestCode1().foo;
  }
  
}// DeprecatedTestCode2
