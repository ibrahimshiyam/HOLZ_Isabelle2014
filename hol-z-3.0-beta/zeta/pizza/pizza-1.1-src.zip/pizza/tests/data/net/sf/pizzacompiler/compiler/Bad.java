/**
 * $Id: Bad.java,v 1.1 2001/09/13 16:54:34 nfortescue Exp $
 *
 * Copyright (C) 2001 Nicolas Fortescue.
 * This software is distributed under the Artistic License. See
 * artistic.html or artistic.txt which came with this distribution.
 *
 * Created: Thu Sep 13 17:22:12 2001
 */

/**
 *a file that shouldn't compile
 */ 
public class Bad {
  public Bad (){
    
    // missing }
  
}// Bad
